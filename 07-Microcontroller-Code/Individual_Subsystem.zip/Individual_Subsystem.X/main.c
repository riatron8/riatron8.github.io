#include "mcc_generated_files/system/system.h"

// Pin macros for clarity
#define MOTOR_FORWARD()  do { LATCbits.LATC5 = 1; LATCbits.LATC6 = 0; } while(0)
#define MOTOR_REVERSE()  do { LATCbits.LATC5 = 0; LATCbits.LATC6 = 1; } while(0)
#define MOTOR_STOP()     do { LATCbits.LATC5 = 0; LATCbits.LATC6 = 0; } while(0)
#define CYCLE_LED_ON()   LATFbits.LATF3 = 0
#define CYCLE_LED_OFF()  LATFbits.LATF3 = 1

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // Configure motor pins as outputs
    TRISCbits.TRISC5 = 0; // RC5 output
    TRISCbits.TRISC6 = 0; // RC6 output

    // Configure LED pin as output
    TRISFbits.TRISF3 = 0;

    // Configure input pins
    TRISAbits.TRISA1 = 1; // Button
    TRISAbits.TRISA2 = 1; // Signal

    while (1)
    {
        // Check if either button/signal is high
        if (PORTAbits.RA1 || PORTAbits.RA2)
        {
            // Start cycle
            CYCLE_LED_ON();

            // Forward for 2 seconds
            MOTOR_FORWARD();
            __delay_ms(1000);

            // Reverse for 2 seconds
            MOTOR_REVERSE();
            __delay_ms(1000);

            // Stop motor
            MOTOR_STOP();
            CYCLE_LED_OFF();
        }
    }
}
